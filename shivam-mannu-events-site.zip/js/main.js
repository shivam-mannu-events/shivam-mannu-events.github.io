/* ===== EDIT HERE ===== */
var C={
  wa:'919140550945',
  form:'' /* paste your Formspree endpoint here, e.g. https://formspree.io/f/abcdwxyz. Empty = WhatsApp only */
};
/* ===================== */
(function(){
var $=function(s,r){return(r||document).querySelector(s)},$$=function(s,r){return[].slice.call((r||document).querySelectorAll(s))};
var wa=function(m){return'https://wa.me/'+C.wa+'?text='+encodeURIComponent(m)};
var reduce=matchMedia('(prefers-reduced-motion:reduce)').matches;

/* menu */
var nv=$('.nav'),mb=$('.mb');
function closeMenu(){nv.classList.remove('open');mb.textContent='☰';mb.setAttribute('aria-expanded','false');mb.setAttribute('aria-label','मेनू खोलें')}
mb.onclick=function(){var o=nv.classList.toggle('open');mb.setAttribute('aria-expanded',o);mb.textContent=o?'✕':'☰';mb.setAttribute('aria-label',o?'मेनू बंद करें':'मेनू खोलें')};
$$('.nav nav a').forEach(function(a){a.onclick=closeMenu});
addEventListener('keydown',function(e){if(e.key=='Escape')closeMenu()});

/* hero video: only on good connections, otherwise the poster stays */
var hv=$('#hv'),cn=navigator.connection||{};
var good=!cn.saveData&&(!cn.effectiveType||cn.effectiveType=='4g')&&!reduce;
if(good&&hv){var go=function(){hv.src=hv.dataset.src;hv.play().catch(function(){})};
  if('requestIdleCallback' in window)requestIdleCallback(go,{timeout:2500});else setTimeout(go,800)}

/* reels: play when visible, tap for sound */
var vs=$$('.vd');
if('IntersectionObserver' in window){
  var vo=new IntersectionObserver(function(es){es.forEach(function(e){var v=$('video',e.target);if(e.isIntersecting&&!reduce)v.play().catch(function(){});else v.pause()})},{threshold:.5});
  vs.forEach(function(d){vo.observe(d)});
}
vs.forEach(function(d){d.onclick=function(){var v=$('video',d);
  vs.forEach(function(x){if(x!==d){$('video',x).muted=true;$('.snd',x).textContent='आवाज़ चालू'}});
  v.muted=!v.muted;$('.snd',d).textContent=v.muted?'आवाज़ चालू':'आवाज़ बंद';v.play().catch(function(){})}});

/* gallery filter + lightbox */
var F=$$('#mas figure'),cur=0,vis=[],lb=$('#lb'),lbi=$('img',lb),last=null;
$$('.chip').forEach(function(c){c.onclick=function(){
  $$('.chip').forEach(function(x){x.setAttribute('aria-pressed',x==c)});
  F.forEach(function(f){f.classList.toggle('h',c.dataset.k!='all'&&f.dataset.c!=c.dataset.k)})}});
function show(i){vis=F.filter(function(f){return!f.classList.contains('h')});cur=(i+vis.length)%vis.length;
  var f=vis[cur],im=$('img',f);lbi.src=f.dataset.full;lbi.alt=im.alt;$('p',lb).textContent=im.alt;
  lb.classList.add('o');$('.x',lb).focus()}
function closeLb(){lb.classList.remove('o');if(last)last.focus()}
F.forEach(function(f){f.onclick=function(){last=f;vis=F.filter(function(x){return!x.classList.contains('h')});show(vis.indexOf(f))};
  f.onkeydown=function(e){if(e.key=='Enter'||e.key==' '){e.preventDefault();f.click()}}});
$('.x',lb).onclick=closeLb;$('.pv',lb).onclick=function(){show(cur-1)};$('.nx',lb).onclick=function(){show(cur+1)};
lb.onclick=function(e){if(e.target==lb)closeLb()};
addEventListener('keydown',function(e){if(!lb.classList.contains('o'))return;
  if(e.key=='Escape')closeLb();if(e.key=='ArrowLeft')show(cur-1);if(e.key=='ArrowRight')show(cur+1);
  if(e.key=='Tab'){var b=$$('button',lb),i=b.indexOf(document.activeElement);e.preventDefault();b[(i+(e.shiftKey?-1:1)+b.length)%b.length].focus()}});
var tx=0;lb.addEventListener('touchstart',function(e){tx=e.touches[0].clientX},{passive:true});
lb.addEventListener('touchend',function(e){var d=e.changedTouches[0].clientX-tx;if(Math.abs(d)>50)show(cur+(d<0?1:-1))},{passive:true});

/* enquiry form: Formspree, WhatsApp fallback */
var form=$('#f'),er=$('#er');
form.onsubmit=function(e){e.preventDefault();
  var f=e.target,v=function(n){return f.elements[n].value.trim()},btn=$('button[type=submit]',f);
  if(v('_gotcha')){done('धन्यवाद!');return}
  if(!v('name')||v('phone').replace(/\D/g,'').length<10){er.textContent='कृपया अपना नाम और सही फोन नंबर (कम से कम 10 अंक) भरें।';(v('name')?f.elements.phone:f.elements.name).focus();return}
  er.textContent='';
  var m='नमस्ते, मैं इवेंट बुक करना चाहता/चाहती हूँ.\nनाम: '+v('name')+'\nफोन: '+v('phone')+'\nइवेंट: '+v('event')+'\nतारीख: '+(v('date')||'-')+'\nमेहमान: '+(v('guests')||'-')+'\nलोकेशन: '+(v('location')||'-')+'\nबजट: '+(v('budget')||'-')+'\nज़रूरतें: '+(v('notes')||'-');
  function done(t){f.style.display='none';$('#okm').textContent=t;$('#ok').style.display='block';$('#ok').scrollIntoView({block:'center'})}
  function fallback(){btn.disabled=false;btn.textContent='Send Event Enquiry';
    er.innerHTML='फॉर्म सीधे नहीं भेजा जा सका। कृपया <a href="'+wa(m)+'" target="_blank" rel="noopener" style="color:var(--gold)">WhatsApp पर यही जानकारी भेजें</a> या हमें कॉल करें।';
    window.open(wa(m),'_blank','noopener')}
  if(!C.form){window.open(wa(m),'_blank','noopener');done('आपकी जानकारी WhatsApp में तैयार है। कृपया वहाँ Send दबाएँ, हम जल्द संपर्क करेंगे।');return}
  btn.disabled=true;btn.textContent='भेज रहे हैं…';
  var ac=window.AbortController?new AbortController():null,t=setTimeout(function(){ac&&ac.abort()},12000);
  fetch(C.form,{method:'POST',body:new FormData(f),headers:{Accept:'application/json'},signal:ac&&ac.signal})
   .then(function(r){clearTimeout(t);r.ok?done('आपकी एन्क्वायरी मिल गई है। हम जल्द ही आपसे संपर्क करेंगे।'):fallback()})
   .catch(function(){clearTimeout(t);fallback()})};

/* reveal on scroll */
var rvs=$$('.rv');
if('IntersectionObserver' in window&&!reduce){var ro=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');ro.unobserve(e.target)}})},{threshold:.05});rvs.forEach(function(x){ro.observe(x)})}
else rvs.forEach(function(x){x.classList.add('in')});
})();
